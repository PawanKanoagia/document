import React from 'react'
import './App.css'
import 'bootstrap/dist/css/bootstrap.css'
import Home from './components/Home'
import Navbar from './components/Navbar'
import { Route, Routes } from 'react-router-dom'
import AboutUs from './components/AboutUs'
import Contact from './components/Contact'
import SignUp from './components/SignUp'
import LogIn from './components/LogIn'
import Errorpage from './components/errorpage'


const App = () => {
  return (
    <> 

      < Navbar/>
    
     
      <Routes>  

    <Route path="/" element={<Home />} />

    <Route path="/aboutus" element={<AboutUs />} />

    <Route path="/contact" element={<Contact />} />

    <Route path="signup" element={<SignUp />} />

    <Route path="/login" element={<LogIn />} />

    <Route path='*' element={<Errorpage />} />

</Routes>

     
{/* 
      <Route path='/'>
      < Home/>
      </Route>

      <Route path='/aboutus'>
      < AboutUs/>
      </Route>

      <Route path='contact'>
      < Contact/>
      </Route>

      <Route path='login'>
      < LogIn/>
      </Route>

      <Route path='/signup'>
      < SignUp/>
      </Route>  */}
    </>
  )
}

export default App
