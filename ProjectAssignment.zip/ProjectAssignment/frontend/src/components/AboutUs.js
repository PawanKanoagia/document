import React from "react";
import Pawan from "../image/pawan.png";
import Abhi from "../image/Abhi.jpg";

const AboutUs = () => {
  return (
    <>
      <div className="about-section">
        <h1>About Us Page</h1>
        <p>Some text about who we are and what we do.</p>
        <p>
          Resize the browser window to see that this page is responsive by the
          way.
        </p>
      </div>

      <h2 className="ourteam">Our Team</h2>
      <table className="table">
        <thead>
          <tr>
            <th scope="col">Full Stack Developer</th>
            <th scope="col">Mern Developer</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>
              <div className="card mx-5">
                <img className="card-img-top" src={Abhi} alt="Card cap" />
                <div className="card-body">
                  <p className="card-text">
                    A professional who is charged with designing and coding
                    software for businesses and consumers alike.
                  </p>
                </div>
              </div>
            </td>
            <td>
              <div className="card">
                <img className="card-img-top" src={Pawan} alt="Card cap" />
                <div className="card-body">
                  <p className="card-text">
                    A professional who is charged with designing and coding
                    software for businesses and consumers alike.
                  </p>
                </div>
              </div>
            </td>
          </tr>
        </tbody>
      </table>
    </>
  );
};

export default AboutUs;
