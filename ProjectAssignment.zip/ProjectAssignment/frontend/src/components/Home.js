import React from 'react'

const Home = () => {
  return (
    <div>
      <p>Welcome to Home page</p>
      <h1>We are  <span className='justify'>the Mern Developer</span>  Community</h1>
    </div>
  )
}

export default Home
