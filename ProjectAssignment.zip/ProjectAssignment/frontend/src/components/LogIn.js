import React, { useState } from 'react'
import { NavLink, useNavigate } from 'react-router-dom'
import signup from '../image/logo.png'

const LogIn = () => {
    const navigate = useNavigate();
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');

    const loginUser = async (e) => {
        e.preventDefault();

        const res = await fetch('/login', {
            method: "POST",
            headers:{
                "Content-Type": "application/json"  
            },
            body:JSON.stringify({
                email,
                password
            })
        });

        const data = res.json();

        if(data.status === 400 || !data){
            window.alert('This is invalid credential');
        }
        else{
            window.alert('This is login successfull')

            navigate('/');
        }
    }


    

  return (
   <>
    <section>
    <div className='signup'>
        <div className='container mt-5'>
            <div className='signup-content'>
                <div className='signup-form'>
                    <h2 className='form-title'>Log In</h2>
                    <form method='POST' className='register-form' id='register-form'>


                        <div className='form-group'>
                            <label htmlFor='email'>
                            <i className="zmdi zmdi-email zmdi-hc-2x material-icons-email"></i>
                            </label>
                            <input type="text" name='email' id='email' autoComplete='off'
                               value={email}
                               onChange={(e) => setEmail(e.target.value)}
                            placeholder='your email'/>
                        </div>


                        <div className='form-group'>
                            <label htmlFor='password'>
                            <i className="zmdi zmdi-lock zmdi-hc-2x  material-icons-password"></i>
                            </label>
                            <input type="text" name='password' id='password' autoComplete='off'
                                value={password}
                                onChange={(e) => setPassword(e.target.value)}
                            placeholder='your password'/>
                        </div>

                    

                        <div className='form-group form-button'>
                            <input type='submit' name='login' id='login' className='form-submit'
                             value='Log In'
                             onClick={loginUser}
                             />
                        </div>

                    </form>
                </div>
                    
                    <div className='signup-image'>
                        <figure>
                            <img src={signup} alt='register pic' />
                        </figure>
                        <NavLink to='/signup' className='signup-image-link'>Create an accounts</NavLink>
                    </div>

            </div>
        </div>
        
    </div>
   </section>
   </>
  )
}

export default LogIn
