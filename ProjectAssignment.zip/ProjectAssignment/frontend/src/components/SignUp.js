import React, { useState } from 'react'
import { NavLink, useNavigate } from 'react-router-dom'
import signup from '../image/logo.png'

const SignUp = () => {
    const navigate = useNavigate();

    const [user, setUser] = useState({
        name: "", email: "", phone: "", work: "", password: "", cpassword: ""
    }); 

    let name, value;
    const handleInputs = (e) =>{
        console.log(e);
        name = e.target.name;
        value = e.target.value;

        setUser({...user ,[name]:value})

    } 

    const PostData = async (e) => {
        e.preventDefault();
         
        const {name, email, phone, work, password, cpassword} = user
        const res =  await fetch('/register', {
            method: "POST",
            headers: {
                "content-type": "application/json"                
            },
            body: JSON.stringify({
                name, email, phone, work, password, cpassword
            })
        });

         const data =  await res.json();
         console.log(data)
        
         if(data.status === 422 || data.error ){
            window.alert(data.error)
            console.log('Invalid Registration')
         }else{
            window.alert('Success Registration')
            console.log('Success Registration')

            navigate('/login');
         }

    }



  return (
   <>
   <section>
    <div className='signup'>
        <div className='container mt-5'>
            <div className='signup-content'>
                <div className='signup-form'>
                    <h2 className='form-title'>Sign Up</h2>
                    <form className='register-form' id='register-form' method='POST'>

                        <div className='form-group'>
                            <label htmlFor='name'>
                            <i className="zmdi zmdi-accounts zmdi-hc-2x material-icons-name"></i>
                            </label>
                            <input type="text" name='name' id='name' autoComplete='off'
                              value={user.name}
                              onChange={handleInputs}
                              placeholder='your name'/>
                        </div>

                        <div className='form-group'>
                            <label htmlFor='email'>
                            <i className="zmdi zmdi-email zmdi-hc-2x material-icons-email"></i>
                            </label>
                            <input type="text" name='email' id='email' autoComplete='off'
                             value={user.email}
                             onChange={handleInputs}
                              placeholder='your email'/>
                        </div>

                        <div className='form-group'>
                            <label htmlFor='phone'>
                            <i className="zmdi zmdi-phone-in-talk zmdi-hc-2x material-icons-phone"></i>
                            </label>
                            <input type="number" name='phone' id='phone' autoComplete='off'
                              value={user.phone}
                              onChange={handleInputs}
                              placeholder='your phone number'/>
                        </div>

                        <div className='form-group'>
                            <label htmlFor='work'>
                            <i className="zmdi zmdi-slideshow zmdi-hc-2x  material-icons-work"></i>
                            </label>
                            <input type="text" name='work' id='work' autoComplete='off'
                             value={user.work}
                             onChange={handleInputs}
                              placeholder='your work'/>
                        </div>

                        <div className='form-group'>
                            <label htmlFor='password'>
                            <i className="zmdi zmdi-lock zmdi-hc-2x  material-icons-password"></i>
                            </label>
                            <input type="password" name='password' id='password' autoComplete='off'
                             value={user.password}
                             onChange={handleInputs}
                              placeholder='your password'/>
                        </div>

                        <div className='form-group'>
                            <label htmlFor='cpassword'>
                            <i className="zmdi zmdi-lock zmdi-hc-2x  material-icons-cpassword"></i>
                            </label>
                            <input type="text" name='cpassword' id='cpassword' autoComplete='off'
                            value={user.cpassword}
                            onChange={handleInputs}
                              placeholder='Conform your password'/>
                        </div>

                        <div className='form-group form-button'>
                            <input type='submit' name='signup' id='signup' className='form-submit' value='register' onClick={PostData}/>
                        </div>

                    </form>
                </div>
                    
                    <div className='signup-image'>
                        <figure>
                            <img src={signup} alt='register pic' />
                        </figure>
                        <NavLink to='/login' className='signup-image-link'>I am already Registered</NavLink>
                    </div>

            </div>
        </div>
        
    </div>
   </section>
   </>
  )
}

export default SignUp
