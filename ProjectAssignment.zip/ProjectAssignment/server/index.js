const express = require('express');
const app = express();

const path = require('path');

const dotenv = require('dotenv');
dotenv.config({path: './config.env'});
const PORT = process.env.PORT;

app.use(express.json());

//userSchema
const User = require('./model/userSchema');
// const authentication = require('./middleware/authentication');





//Database
require('./db/conn');


app.use(require('./router/auth'));


//middleware 

// const middleware = (req, res, next) => {
//     console.log('Welcome to middleware function');
//     next();
// }


app.get('/about' , (req, res)=>{
    res.send('Hello world welcome to about from the server');
})


app.listen(PORT, () =>{
    console.log(`server running on port ${PORT}`);
})